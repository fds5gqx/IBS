package com.example.gmp.exdbproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Sell extends AppCompatActivity {

    LinearLayout cl;
    TextView cn1,cn2,cn3,cn4,cn5;
    TextView cp1,cp2,cp3,cp4,cp5;
    TextView cc1,cc2,cc3,cc4,cc5;
    TextView cg1,cg2,cg3,cg4,cg5;
    String price;

    FirebaseDatabase fdb = FirebaseDatabase.getInstance();
    DatabaseReference rdb = fdb.getReference("money");
    DatabaseReference rdb2 = fdb.getReference("user");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);

        Intent intent = getIntent();
        final String user_id = intent.getStringExtra("id");
        cl = (LinearLayout) findViewById(R.id.cccl1);

        cn1 = (TextView) findViewById(R.id.company_title1);
        cn1.setText("KB금융 ");
        cp1 = (TextView) findViewById(R.id.company_price1);
        cc1 = (TextView) findViewById(R.id.company_climb1);
        cg1= (TextView) findViewById(R.id.company_get1);

        rdb.child("KB금융 ").child("등락율").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cc1.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child("KB금융 ").child("현재 가격").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cp1.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb2.child(user_id).child("KB금융").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cg1.setText("보유 갯수 : " + str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder ad = new AlertDialog.Builder(Sell.this);
                ad.setTitle("KB금융");
                final String price_set = cp1.getText().toString();
                ad.setMessage("가격 : " + price_set);
                final EditText et = new EditText(Sell.this);
                ad.setView(et);
                ad.setPositiveButton("Sell", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final int price = Integer.parseInt(price_set);
                        final int cnt = Integer.parseInt(et.getText().toString());
                        rdb2.child(user_id).child("cash").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int cash = Integer.parseInt(dataSnapshot.getValue().toString());
                                rdb2.child(user_id).child("cash").setValue(cash + (price * cnt));
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        rdb2.child(user_id).child("KB금융").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int user_cnt = Integer.parseInt(dataSnapshot.getValue().toString());
                                if((user_cnt - cnt) < 0) Toast.makeText(getApplicationContext(), "More than get", Toast.LENGTH_SHORT).show();
                                else {
                                    rdb2.child(user_id).child("KB금융").setValue(user_cnt - cnt);
                                    Toast.makeText(getApplicationContext(), "Sell Success", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                ad.show();
            }
        });


        cl = (LinearLayout) findViewById(R.id.ccc2);
        cn2 = (TextView) findViewById(R.id.company_title2);
        cn2.setText("NAVER");
        cp2 = (TextView) findViewById(R.id.company_price2);
        cc2 = (TextView) findViewById(R.id.company_climb2);
        cg2 = (TextView) findViewById(R.id.company_get2);

        rdb.child("NAVER ").child("등락율").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cc2.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child("NAVER ").child("현재 가격").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cp2.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb2.child(user_id).child("NAVER").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cg2.setText("보유 갯수 : " + str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder ad = new AlertDialog.Builder(Sell.this);
                ad.setTitle("NAVER");
                final String price_set = cp2.getText().toString();
                ad.setMessage("가격 : " + price_set);
                final EditText et = new EditText(Sell.this);
                ad.setView(et);
                ad.setPositiveButton("Sell", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final int price = Integer.parseInt(price_set);
                        final int cnt = Integer.parseInt(et.getText().toString());
                        rdb2.child(user_id).child("cash").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int cash = Integer.parseInt(dataSnapshot.getValue().toString());
                                rdb2.child(user_id).child("cash").setValue(cash + (price * cnt));
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        rdb2.child(user_id).child("NAVER").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int user_cnt = Integer.parseInt(dataSnapshot.getValue().toString());
                                if((user_cnt - cnt) < 0) Toast.makeText(getApplicationContext(), "More than get", Toast.LENGTH_SHORT).show();
                                else {
                                    rdb2.child(user_id).child("NAVER").setValue(user_cnt - cnt);
                                    Toast.makeText(getApplicationContext(), "Sell Success", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                ad.show();
            }
        });


        cl = (LinearLayout) findViewById(R.id.ccc3);
        cn3 = (TextView) findViewById(R.id.company_title3);
        cn3.setText("SK텔레콤");
        cp3 = (TextView) findViewById(R.id.company_price3);
        cc3 = (TextView) findViewById(R.id.company_climb3);
        cg3 = (TextView) findViewById(R.id.company_get3);

        rdb.child("SK텔레콤 ").child("등락율").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cc3.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child("SK텔레콤 ").child("현재 가격").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cp3.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb2.child(user_id).child("SK텔레콤").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cg3.setText("보유 갯수 : " + str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder ad = new AlertDialog.Builder(Sell.this);
                ad.setTitle("SK텔레콤");
                final String price_set = cp3.getText().toString();
                ad.setMessage("가격 : " + price_set);
                final EditText et = new EditText(Sell.this);
                ad.setView(et);
                ad.setPositiveButton("Sell", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final int price = Integer.parseInt(price_set);
                        final int cnt = Integer.parseInt(et.getText().toString());
                        rdb2.child(user_id).child("cash").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int cash = Integer.parseInt(dataSnapshot.getValue().toString());
                                rdb2.child(user_id).child("cash").setValue(cash + (price * cnt));
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        rdb2.child(user_id).child("SK텔레콤").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int user_cnt = Integer.parseInt(dataSnapshot.getValue().toString());
                                if((user_cnt - cnt) < 0) Toast.makeText(getApplicationContext(), "More than get", Toast.LENGTH_SHORT).show();
                                else {
                                    rdb2.child(user_id).child("SK텔레콤").setValue(user_cnt - cnt);
                                    Toast.makeText(getApplicationContext(), "Sell Success", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                ad.show();
            }
        });


        cl = (LinearLayout) findViewById(R.id.ccc4);
        cn4 = (TextView) findViewById(R.id.company_title4);
        cn4.setText("삼성전자");
        cp4 = (TextView) findViewById(R.id.company_price4);
        cc4 = (TextView) findViewById(R.id.company_climb4);
        cg4 = (TextView) findViewById(R.id.company_get4);

        rdb.child("삼성전자 ").child("등락율").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cc4.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child("삼성전자 ").child("현재 가격").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cp4.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb2.child(user_id).child("삼성전자").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cg4.setText("보유 갯수 : " + str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder ad = new AlertDialog.Builder(Sell.this);
                ad.setTitle("삼성전자");
                final String price_set = cp4.getText().toString();
                ad.setMessage("가격 : " + price_set);
                final EditText et = new EditText(Sell.this);
                ad.setView(et);
                ad.setPositiveButton("Sell", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final int price = Integer.parseInt(price_set);
                        final int cnt = Integer.parseInt(et.getText().toString());
                        rdb2.child(user_id).child("cash").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int cash = Integer.parseInt(dataSnapshot.getValue().toString());
                                rdb2.child(user_id).child("cash").setValue(cash + (price * cnt));
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        rdb2.child(user_id).child("삼성전자").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int user_cnt = Integer.parseInt(dataSnapshot.getValue().toString());
                                if((user_cnt - cnt) < 0) Toast.makeText(getApplicationContext(), "More than get", Toast.LENGTH_SHORT).show();
                                else {
                                    rdb2.child(user_id).child("삼성전자").setValue(user_cnt - cnt);
                                    Toast.makeText(getApplicationContext(), "Sell Success", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                ad.show();
            }
        });

        cl = (LinearLayout) findViewById(R.id.ccc5);
        cn5 = (TextView) findViewById(R.id.company_title5);
        cn5.setText("현대모비스");
        cp5 = (TextView) findViewById(R.id.company_price5);
        cc5 = (TextView) findViewById(R.id.company_climb5);
        cg5 = (TextView) findViewById(R.id.company_get5);

        rdb.child("현대모비스 ").child("등락율").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cc5.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child("현대모비스 ").child("현재 가격").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cp5.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb2.child(user_id).child("현대모비스").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                cg5.setText("보유 갯수 : " + str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder ad = new AlertDialog.Builder(Sell.this);
                ad.setTitle("현대모비스");
                final String price_set = cp5.getText().toString();
                ad.setMessage("가격 : " + price_set);
                final EditText et = new EditText(Sell.this);
                ad.setView(et);
                ad.setPositiveButton("Sell", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final int price = Integer.parseInt(price_set);
                        final int cnt = Integer.parseInt(et.getText().toString());
                        rdb2.child(user_id).child("cash").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int cash = Integer.parseInt(dataSnapshot.getValue().toString());
                                rdb2.child(user_id).child("cash").setValue(cash + (price * cnt));
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        rdb2.child(user_id).child("현대모비스").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int user_cnt = Integer.parseInt(dataSnapshot.getValue().toString());
                                if((user_cnt - cnt) < 0) Toast.makeText(getApplicationContext(), "More than get", Toast.LENGTH_SHORT).show();
                                else {
                                    rdb2.child(user_id).child("현대모비스").setValue(user_cnt - cnt);
                                    Toast.makeText(getApplicationContext(), "Sell Success", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                ad.show();
            }
        });




    }

}
