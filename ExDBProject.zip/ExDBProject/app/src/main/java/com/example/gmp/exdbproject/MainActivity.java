package com.example.gmp.exdbproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    EditText user_id;
    EditText passwd;
    Button btn;
    Button btn2;

    FirebaseDatabase fdb = FirebaseDatabase.getInstance();
    DatabaseReference rdb = fdb.getReference("user");

    private static MediaPlayer mp;

    @Override
    protected void onResume() {
        super.onResume();
        mp.start();
    }

    @Override
    protected void onDestroy() {
        mp.stop();
        super.onDestroy();
    }

    @Override
    protected void onUserLeaveHint() {
        mp.pause();
        super.onUserLeaveHint();
    }

    @Override
    public void onBackPressed() {
        mp.stop();
        super.onBackPressed();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        user_id = (EditText)findViewById(R.id.id_input);
        passwd = (EditText)findViewById(R.id.pwd_input);
        btn = (Button)findViewById(R.id.login_button);
        btn2 = (Button)findViewById(R.id.login_button2);

            mp = MediaPlayer.create(this,R.raw.e);
            mp.setLooping(true);
            mp.start();

        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                rdb.child(user_id.getText().toString()).child("password").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        try {
                            if (passwd.getText().toString().equals(dataSnapshot.getValue().toString())) {
                                Toast.makeText(getApplicationContext(), "login sucess", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), SelectView.class); // 다음 넘어갈 클래스 지정
                                intent.putExtra("id", user_id.getText().toString());
                                startActivity(intent);
                                //finish();
                            } else
                                Toast.makeText(getApplicationContext(), "check your id or password", Toast.LENGTH_SHORT).show();
                        }catch(Exception e){
                            Toast.makeText(getApplicationContext(), "check your id or password", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                showDialog();
            }
        });

    }
    public void showDialog() {

        AlertDialog.Builder ad = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.signup_dialog, null);
        ad.setView(view);
        final EditText signID = (EditText)view.findViewById(R.id.id_input_sign);
        final EditText signPW = (EditText)view.findViewById(R.id.pwd_input_sign);

        ad.setPositiveButton("Sign Up", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                rdb.child(signID.getText().toString()).child("password").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        try{
                            String str = dataSnapshot.getValue().toString();
                            Toast.makeText(getApplicationContext(), "This id is already exist", Toast.LENGTH_SHORT).show();
                        }catch(Exception e){
                            rdb.child(signID.getText().toString()).child("password").setValue(signPW.getText().toString());
                            rdb.child(signID.getText().toString()).child("cash").setValue(1000000);
                            Toast.makeText(getApplicationContext(), "Sign Up!!", Toast.LENGTH_SHORT).show();
                            /*///////디폴트 데이터 입력
                            rdb.child(signID.getText().toString()).child("josic1").setValue("0");
                            rdb.child(signID.getText().toString()).child("josic1have").setValue("0");
                            rdb.child(signID.getText().toString()).child("josic2").setValue("0");
                            rdb.child(signID.getText().toString()).child("josic2have").setValue("0");
                            rdb.child(signID.getText().toString()).child("josic3").setValue("0");
                            rdb.child(signID.getText().toString()).child("josic3have").setValue("0");
                            rdb.child(signID.getText().toString()).child("josic4").setValue("0");
                            rdb.child(signID.getText().toString()).child("josic4have").setValue("0");
                            rdb.child(signID.getText().toString()).child("josic5").setValue("0");
                            rdb.child(signID.getText().toString()).child("josic5have").setValue("0");

                            ////////////////////////////*/
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });



        AlertDialog dialog = ad.create();
        dialog.show();
    }
}
