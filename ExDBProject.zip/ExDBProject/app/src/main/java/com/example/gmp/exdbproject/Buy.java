package com.example.gmp.exdbproject;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Buy extends AppCompatActivity {

    LinearLayout cl;
    TextView tv1,tv2,tv3,tv4,tv5;
    TextView tx1,tx2,tx3,tx4,tx5;
    TextView ty1,ty2,ty3,ty4,ty5;
    String price;

    FirebaseDatabase fdb = FirebaseDatabase.getInstance();
    DatabaseReference rdb = fdb.getReference("money");
    DatabaseReference rdb2 = fdb.getReference("user");
    String[] ju =  { "KB금융 ", "","" ,"" ,""};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy);

        Intent intent = getIntent();
        final String user_id = intent.getStringExtra("id");
        cl = (LinearLayout) findViewById(R.id.cccl1);

    tv1 = (TextView) findViewById(R.id.company_title1);
        tv1.setText(ju[0]);
    tx1 = (TextView) findViewById(R.id.company_price1);
    ty1 = (TextView) findViewById(R.id.company_climb1);


        rdb.child("KB금융 ").child("등락율").addListenerForSingleValueEvent(new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            String str = dataSnapshot.getValue().toString();
            ty1.setText(str);
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {
            Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
        }
    });
        rdb.child("KB금융 ").child("현재 가격").addListenerForSingleValueEvent(new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            String str = dataSnapshot.getValue().toString();
            tx1.setText(str);
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {
            Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
        }
    });


        cl.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            AlertDialog.Builder ad = new AlertDialog.Builder(Buy.this);
            ad.setTitle("KB금융");
            final String price_set = tx2.getText().toString();
            ad.setMessage("가격 : " + price_set);
            final EditText et = new EditText(Buy.this);
            ad.setView(et);
            ad.setPositiveButton("Buy", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    final int price = Integer.parseInt(price_set);
                    final int cnt = Integer.parseInt(et.getText().toString());
                    rdb2.child(user_id).child("cash").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            int cash = Integer.parseInt(dataSnapshot.getValue().toString());
                            if(cash-(price * cnt) < 0) Toast.makeText(getApplicationContext(), "Not Enough Money", Toast.LENGTH_SHORT).show();
                            else {
                                rdb2.child(user_id).child("cash").setValue(cash - (price * cnt));
                                rdb2.child(user_id).child("KB금융").addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        int user_cnt = Integer.parseInt(dataSnapshot.getValue().toString());
                                        rdb2.child(user_id).child("KB금융").setValue(user_cnt+cnt);
                                        Toast.makeText(getApplicationContext(), "Buy Success", Toast.LENGTH_SHORT).show();
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                        Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            ad.show();
        }
    });
        cl = (LinearLayout) findViewById(R.id.ccc2);

        tv2 = (TextView) findViewById(R.id.company_title2);
        tv2.setText("NAVER");
        tx2 = (TextView) findViewById(R.id.company_price2);
        ty2 = (TextView) findViewById(R.id.company_climb2);


        rdb.child("NAVER ").child("등락율").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                ty2.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child("NAVER ").child("현재 가격").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                tx2.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });


        cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder ad = new AlertDialog.Builder(Buy.this);
                ad.setTitle("NAVER");
                final String price_set = tx2.getText().toString();
                ad.setMessage("가격 : " + price_set);
                final EditText et = new EditText(Buy.this);
                ad.setView(et);
                ad.setPositiveButton("Buy", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final int price = Integer.parseInt(price_set);
                        final int cnt = Integer.parseInt(et.getText().toString());
                        rdb2.child(user_id).child("cash").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int cash = Integer.parseInt(dataSnapshot.getValue().toString());
                                if(cash-(price * cnt) < 0) Toast.makeText(getApplicationContext(), "Not Enough Money", Toast.LENGTH_SHORT).show();
                                else {
                                    rdb2.child(user_id).child("cash").setValue(cash - (price * cnt));
                                    rdb2.child(user_id).child("NAVER").addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            int user_cnt = Integer.parseInt(dataSnapshot.getValue().toString());
                                            rdb2.child(user_id).child("NAVER").setValue(user_cnt+cnt);
                                            Toast.makeText(getApplicationContext(), "Buy Success", Toast.LENGTH_SHORT).show();
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {
                                            Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                ad.show();
            }
        });
        cl = (LinearLayout) findViewById(R.id.ccc3);

        tv3 = (TextView) findViewById(R.id.company_title3);
        tv3.setText("SK텔레콤");
        tx3 = (TextView) findViewById(R.id.company_price3);
        ty3 = (TextView) findViewById(R.id.company_climb3);


        rdb.child("SK텔레콤 ").child("등락율").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                ty3.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child("SK텔레콤 ").child("현재 가격").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                tx3.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });


        cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder ad = new AlertDialog.Builder(Buy.this);
                ad.setTitle("SK텔레콤");
                final String price_set = tx3.getText().toString();
                ad.setMessage("가격 : " + price_set);
                final EditText et = new EditText(Buy.this);
                ad.setView(et);
                ad.setPositiveButton("Buy", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final int price = Integer.parseInt(price_set);
                        final int cnt = Integer.parseInt(et.getText().toString());
                        rdb2.child(user_id).child("cash").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int cash = Integer.parseInt(dataSnapshot.getValue().toString());
                                if(cash-(price * cnt) < 0) Toast.makeText(getApplicationContext(), "Not Enough Money", Toast.LENGTH_SHORT).show();
                                else {
                                    rdb2.child(user_id).child("cash").setValue(cash - (price * cnt));
                                    rdb2.child(user_id).child("SK텔레콤").addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            int user_cnt = Integer.parseInt(dataSnapshot.getValue().toString());
                                            rdb2.child(user_id).child("SK텔레콤").setValue(user_cnt+cnt);
                                            Toast.makeText(getApplicationContext(), "Buy Success", Toast.LENGTH_SHORT).show();
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {
                                            Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                ad.show();
            }
        });
        cl = (LinearLayout) findViewById(R.id.ccc4);

        tv4 = (TextView) findViewById(R.id.company_title4);
        tv4.setText("삼성전자");
        tx4 = (TextView) findViewById(R.id.company_price4);
        ty4 = (TextView) findViewById(R.id.company_climb4);


        rdb.child("삼성전자 ").child("등락율").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                ty4.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child("삼성전자 ").child("현재 가격").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                tx4.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });


        cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder ad = new AlertDialog.Builder(Buy.this);
                ad.setTitle("삼성전자");
                final String price_set = tx5.getText().toString();
                ad.setMessage("가격 : " + price_set);
                final EditText et = new EditText(Buy.this);
                ad.setView(et);
                ad.setPositiveButton("Buy", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final int price = Integer.parseInt(price_set);
                        final int cnt = Integer.parseInt(et.getText().toString());

                        rdb2.child(user_id).child("cash").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int cash = Integer.parseInt(dataSnapshot.getValue().toString());
                                if(cash-(price * cnt) < 0) Toast.makeText(getApplicationContext(), "Not Enough Money", Toast.LENGTH_SHORT).show();
                                else {
                                    rdb2.child(user_id).child("cash").setValue(cash - (price * cnt));
                                    rdb2.child(user_id).child("삼성전자").addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            int user_cnt = Integer.parseInt(dataSnapshot.getValue().toString());
                                            rdb2.child(user_id).child("삼성전자").setValue(user_cnt+cnt);
                                            Toast.makeText(getApplicationContext(), "Buy Success", Toast.LENGTH_SHORT).show();
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {
                                            Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                ad.show();
            }
        });
        cl = (LinearLayout) findViewById(R.id.ccc5);

        tv5 = (TextView) findViewById(R.id.company_title5);
        tv5.setText("현대모비스");
        tx5 = (TextView) findViewById(R.id.company_price5);
        ty5 = (TextView) findViewById(R.id.company_climb5);


        rdb.child("현대모비스 ").child("등락율").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                ty5.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child("현대모비스 ").child("현재 가격").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String str = dataSnapshot.getValue().toString();
                tx5.setText(str);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });


        cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder ad = new AlertDialog.Builder(Buy.this);
                ad.setTitle("현대모비스");
                final String price_set = tx5.getText().toString();
                ad.setMessage("가격 : " + price_set);
                final EditText et = new EditText(Buy.this);
                ad.setView(et);
                ad.setPositiveButton("Buy", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final int price = Integer.parseInt(price_set);
                        final int cnt = Integer.parseInt(et.getText().toString());

                        rdb2.child(user_id).child("cash").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int cash = Integer.parseInt(dataSnapshot.getValue().toString());
                                if(cash-(price * cnt) < 0) Toast.makeText(getApplicationContext(), "Not Enough Money", Toast.LENGTH_SHORT).show();
                                else {
                                    rdb2.child(user_id).child("cash").setValue(cash - (price * cnt));
                                    rdb2.child(user_id).child("현대모비스").addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            int user_cnt = Integer.parseInt(dataSnapshot.getValue().toString());
                                            rdb2.child(user_id).child("현대모비스").setValue(user_cnt+cnt);
                                            Toast.makeText(getApplicationContext(), "Buy Success", Toast.LENGTH_SHORT).show();
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {
                                            Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                ad.show();
            }
        });
}

}
