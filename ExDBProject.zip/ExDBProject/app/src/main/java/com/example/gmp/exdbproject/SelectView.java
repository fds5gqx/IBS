package com.example.gmp.exdbproject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.GlideDrawableImageViewTarget;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SelectView extends AppCompatActivity {

    TextView idText;
    TextView cashText;
    TextView kbText;
    TextView nvText;
    TextView skText;
    TextView saText;
    TextView hyText;
    Button workBtn;
    Button buyFin;
    Button sellFin;

    FirebaseDatabase fdb = FirebaseDatabase.getInstance();
    DatabaseReference rdb = fdb.getReference("user");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_main);

        ImageView rabbit = (ImageView) findViewById(R.id.gif_image);
        GlideDrawableImageViewTarget gifImage = new GlideDrawableImageViewTarget(rabbit);
        Glide.with(this).load(R.drawable.ganan).into(gifImage);

        Intent intent = getIntent();
        idText = (TextView)findViewById(R.id.textID);
        cashText = (TextView)findViewById(R.id.textCash);
        kbText = (TextView)findViewById(R.id.textKB);
        nvText = (TextView)findViewById(R.id.textNAVER);
        skText = (TextView)findViewById(R.id.textSK);
        saText = (TextView)findViewById(R.id.textSam);
        hyText = (TextView)findViewById(R.id.textHyun);

        final String str = intent.getStringExtra("id");
        idText.setText("ID : " + str);
        rdb.child(str).child("cash").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                cashText.setText("지갑 잔액 : " + dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child(str).child("KB금융").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                kbText.setText("[KB금융] 보유 : " + dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child(str).child("NAVER").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                nvText.setText("[NAVER] 보유: " + dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child(str).child("SK텔레콤").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                skText.setText("[SK텔레콤] 보유: " + dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child(str).child("삼성전자").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                saText.setText("[삼성전자] 보유 : " + dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });
        rdb.child(str).child("현대모비스").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                hyText.setText("[현대모비스] 보유 : " + dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "DB error", Toast.LENGTH_SHORT).show();
            }
        });


        workBtn = (Button)findViewById(R.id.Work);
        workBtn.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ActWork.class);
                intent.putExtra("id",str);
                startActivity(intent);
                //finish();
            }

        });

        buyFin = (Button)findViewById(R.id.Fianece);
        buyFin.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                //Intent intent = new Intent(getApplicationContext(),Buy.class);
                Intent intent = new Intent(getApplicationContext(),Buy.class);
                intent.putExtra("id",str);
                startActivity(intent);
                //finish();
            }
        });

        sellFin = (Button)findViewById(R.id.Fianece2);
        sellFin.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Sell.class);
                intent.putExtra("id",str);
                startActivity(intent);
                //finish();
            }
        });

    }
}
